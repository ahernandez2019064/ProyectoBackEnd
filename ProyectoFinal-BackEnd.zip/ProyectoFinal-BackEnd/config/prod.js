module.exports = {
    jwt:{
        secreto: 'secretodeproduccion',
        tiempoDeExpiracion: '12h'
    }
}