module.exports = {
    jwt: {
        secreto: 'secretodedesarrollo',
        tiempoDeExpiracion: '24h'
    }
}